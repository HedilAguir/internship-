#include <jni.h>
#include <string>
#include <stdio.h>
#include <unistd.h> //Used for UART
#include <fcntl.h> //Used for UART
#include <termios.h> //Used for UART
#include <android/log.h>

static int uart0_filestream = -1;
unsigned char tx_buffer[20];
unsigned char *p_tx_buffer;

extern "C"
JNIEXPORT jboolean JNICALL
Java_com_example_pfeuart_MainActivity_UARTInit(JNIEnv *env, jobject thiz) {

    uart0_filestream = open("/dev/ttymxc2", O_RDWR | O_NOCTTY | O_NDELAY); //Open in non blocking read/write mode
    if (uart0_filestream == -1)
    {
        //ERROR - CAN'T OPEN SERIAL PORT
        printf("Error - Unable to open UART.  Ensure it is not in use by another application\n");
    }

    struct termios options;
    tcgetattr(uart0_filestream, &options);
    options.c_cflag = B9600 | CS8 | CLOCAL | CREAD; //<Set baud rate

    options.c_iflag = IGNPAR;
    options.c_oflag = 0;
    options.c_lflag = 0;
    tcflush(uart0_filestream, TCIFLUSH);
    tcsetattr(uart0_filestream, TCSANOW, &options);

    return true;
}
extern "C"
JNIEXPORT jstring JNICALL
Java_com_example_pfeuart_MainActivity_UARTread(JNIEnv *env, jobject thiz) {

    char rx_buffer[256];
    if (uart0_filestream != -1)
    {
        int rx_length = read(uart0_filestream, (void*)rx_buffer, 255);
        if (rx_length < 0)
        {
//An error occured (will occur if there are no bytes)
        }
        else if (rx_length == 0)
        {
//No data waiting
        }
        else
        {
//Bytes received
            rx_buffer[rx_length] = '\0';
            printf("%i bytes read : %s\n", rx_length, rx_buffer);
        }
    }
    return env->NewStringUTF(rx_buffer);
    close(uart0_filestream);
}

extern "C"
JNIEXPORT jboolean JNICALL
Java_com_example_pfeuart_MainActivity_UARTsend(JNIEnv *env, jobject thiz, jstring tx_string) {
    if (uart0_filestream != -1) {
        std::string st((char*)tx_string);
        write(uart0_filestream, "AT\n", 3);
    }
    return true;
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_example_pfeuart_MainActivity_stringFromJNI(
        JNIEnv* env,
        jobject /* this */) {
    std::string hello = "Hello from C++";
    return env->NewStringUTF(hello.c_str());
}