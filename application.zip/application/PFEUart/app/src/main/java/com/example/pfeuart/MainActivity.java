package com.example.pfeuart;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.CountDownTimer;
import android.widget.TextView;

import com.example.pfeuart.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {

    // Used to load the 'pfeuart' library on application startup.
    static {
        System.loadLibrary("pfeuart");
    }

    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Example of a call to a native method
        //tv.setText(stringFromJNI());
        UARTInit();
        UARTsend("1");
        TextView tv = binding.sampleText;
        new CountDownTimer(50000, 10000) {
            public void onTick(long millisUntilFinished) {
                // Used for formatting digit to be in 2 digits only
                /*
                NumberFormat f = new DecimalFormat("00");
                long hour = (millisUntilFiniœshed / 3600000) % 24;
                long min = (millisUntilFinished / 60000) % 60;
                long sec = (millisUntilFinished / 1000) % 60;
                textView.setText(f.format(hour) + ":" + f.format(min) + ":" + f.format(sec));
                 */
                TextView tv = binding.sampleText;

                tv.setText(UARTread().toString());
            }
            // When the task is over it will print 00:00:00 there
            public void onFinish() {
                TextView tv1 = binding.sampleText;
                tv1.setText("00:00:00");
            }
        }.start();    }

    /**
     * A native method that is implemented by the 'pfeuart' native library,
     * which is packaged with this application.
     */
    public native String stringFromJNI();
    public native boolean UARTInit();
    public native String UARTread();
    public native boolean UARTsend(String tx_string);


}